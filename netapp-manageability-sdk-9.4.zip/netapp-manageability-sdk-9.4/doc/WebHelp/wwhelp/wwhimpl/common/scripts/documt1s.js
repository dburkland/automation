// Copyright (c) 2000-2014 Quadralay Corporation.  All rights reserved.
//
/*jslint newcap: true, sloppy: true, vars: true, white: true */
/*global WWHFrame */
/*global WWHBookData_MatchTopic */

// Match topic
//
WWHFrame.WWHHelp.fProcessTopicResult(WWHBookData_MatchTopic(WWHFrame.WWHHelp.mTopicTag));
